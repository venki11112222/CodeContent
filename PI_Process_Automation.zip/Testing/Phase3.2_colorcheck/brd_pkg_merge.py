'''
Board and Package File merge
'''

import os, sys,time
import colorama
from colorama import init,Fore, Back, Style
colorama.init()

# debug mode for developer
debug_mode = False

# PowerSI installed path on the local machine
powersi_path = "C:\\Cadence\\Sigrity2021.1\\tools\\bin\\PowerSI.exe"


# Key variables
oldckt = "oldckt"
newckt = "newckt"
s_ball = "s_ball"
pkg = "pkg"
measurement = "measurement"
pkgpcb = "pkg&pcb"

# variables values
oldckt_value = "BRDU1"
newckt_value = "PKGA1"
s_ball_value = "SolderBall"
pkg_value = "InheritPkg"
measurement_value = "mm"
pkgpcb_value = "PKG&PCB"

# dict for cmd_import_pkg
pkg_import_data = {oldckt: oldckt_value, newckt: newckt_value, s_ball: s_ball_value, pkg: pkg_value, measurement:measurement_value, pkgpcb: pkgpcb_value}

def cmd_open_pkd_tgz(tgz_path):
    cmd = "sigrity::open document {" + tgz_path + "} {!}\n"
    return cmd


def cmd_import_stkup(stkup_path):
    cmd = "sigrity::import stackup {" + stkup_path + "} {!}\n"
    return cmd


def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd


def close_pkg_file():
    cmd = "sigrity::close document {!} \n"
    return cmd


def cmd_open_brd(brd_file_path):
    cmd = "sigrity::open document {" + brd_file_path + "} {!}\n"
    return cmd


def cmd_import_pkg(pkg_import_data):
    '''
    pkg_import_data["spd_path_value"]- path of spd file
    pkg_import_data["Height_value"]- solder ball height
    pkg_import_data["Radius_value"]-solder ball radius

    Example: 
    import PKG -SPDFile {E:/Share/VakulabharanamX/pkg_and_brd_files/pkg_file/dg256eu_ww45p3_pisimulation.spd} -OldCkt {BRDU1} 
    -NewCkt {PKGA1} -method {SolderBall} -MatchSel {InheritPkg} -unit {mm} -height {4.7264e-02} -radius {2.4498e-02} -Prefix -ApplyTo {PKG&PCB} {!}

    '''
    cmd = r"sigrity::import PKG -SPDFile {" + pkg_import_data["spd_path_value"] + "} -OldCkt {" + pkg_import_data[oldckt] + "} -NewCkt {" + \
          pkg_import_data[newckt] + "} -method {" + pkg_import_data[s_ball] + "} -MatchSel {" + pkg_import_data[pkg] + "} -unit {" + pkg_import_data[measurement] + "} -height {" + \
          pkg_import_data["Height_value"] + "} -radius {" + pkg_import_data["Radius_value"] + "} -Prefix -ApplyTo {" + pkg_import_data[pkgpcb] + "} {!}" + "\n"
    if debug_mode:
        print("The import package path is:", cmd)
    return cmd


def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd


def file_updation(cmd_list):
    try:
        with open("brd_pkg_merge.tcl", 'w') as file:
            file.writelines(cmd_list)
        return True
    except Exception as err:
        print("Error while opening file brd_pkg_merge.tcl",err)
        return False


def execute_cmd(tclfile_path):
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path

    if debug_mode:
        print("The command executing is:", execute_cmd)
    print(Fore.GREEN+"Please wait!! Files are processing to merge..."+Fore.RESET)
    os.system(execute_cmd)
    print(Fore.GREEN+"Board and Package files are merged."+Fore.RESET)


def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(Fore.CYAN)
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width-4))
    print(g_line)
    print(Style.RESET_ALL)

def get_input_from_user(cmd_list=[]):
    try:
        my_text_frame("                                         BOARD AND PACKAGE FILE MERGE".splitlines())
        print(Fore.YELLOW +"Enter the pakage(tgz) file path: "+ Style.RESET_ALL,end="")
        tgz_path = input()
        if (os.path.isfile(tgz_path)):
            cmd_list.append(cmd_open_pkd_tgz(tgz_path))
        else:
            print(Fore.YELLOW +"Please recheck the entered path and .tgz file present or not"+ Style.RESET_ALL)
            time.sleep(30)
            sys.exit()
        #.spd file path
        pkg_import_data["spd_path_value"] = tgz_path[0:-3] + "spd"
        
        print(Fore.YELLOW +"Enter the stackup file path: "+ Style.RESET_ALL,end="")
        stkup_path = input()
        if (os.path.isfile(stkup_path)):
            cmd_list.append(cmd_import_stkup(stkup_path))
        else:
            print(Fore.YELLOW +"Please recheck the entered path and .csv file present or not"+ Style.RESET_ALL)
            time.sleep(30)
            sys.exit()

        #Saving the file
        cmd_list.append(cmd_save_file())

        #Closing of package file
        cmd_list.append(close_pkg_file())

        print(Fore.YELLOW +"Enter the Board file path: "+ Style.RESET_ALL,end="")
        brd_file_path = input()
        if (os.path.isfile(brd_file_path)):
            cmd_list.append(cmd_open_brd(brd_file_path))
        else:
            print(Fore.YELLOW +"Please recheck the entered path and .brd file present or not"+ Style.RESET_ALL)
            time.sleep(30)
            sys.exit()

        print(Fore.YELLOW +"Enter the solderball height in mm: "+ Style.RESET_ALL,end="")
        Height_value=input()
        if Height_value=='':
            print(Fore.YELLOW+"Please check the entered solderball height"+Style.RESET_ALL)
            time.sleep(30)
            sys.exit()
        else:
            pkg_import_data["Height_value"] = Height_value

        print(Fore.YELLOW +"Enter the solderball radius in mm: "+ Style.RESET_ALL,end="")
        Radius_value=input()
        if Radius_value=='':
            print(Fore.YELLOW+"Please check the entered solderball radius"+Style.RESET_ALL)
            time.sleep(30)
            sys.exit()
        else:
            pkg_import_data["Radius_value"] = Radius_value 
        
        cmd_list.append(cmd_import_pkg(pkg_import_data))
        cmd_list.append(cmd_save_file())
        return cmd_list
    except Exception as error:
        print(Fore.RED+"The Error raised from get_input_from_user function is:"+Style.RESET_ALL,error)
        print(Fore.RED + error + Style.RESET_ALL)
        time.sleep(50)
        sys.exit()


def tcl_execution():
    tcl_path = os.getcwd()
    if debug_mode:
        print("The tcl script file path is: ",tcl_path)
    tclfile_path =tcl_path + "\\brd_pkg_merge.tcl"
    execute_cmd(tclfile_path)



if __name__ == "__main__":
    file_updation(get_input_from_user(cmd_list=[]))

    tcl_execution()
