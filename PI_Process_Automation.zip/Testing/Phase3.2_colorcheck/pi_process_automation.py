import brd_pkg_merge as brdpkg
import net_select as netsel
import port_components as portcomp
import sys,time
import colorama
from colorama import init,Fore, Back, Style

colorama.init()

def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(Fore.CYAN)
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width-4))
    print(g_line)
    print(Style.RESET_ALL)

def brd_pkg():
    brdpkg.file_updation(brdpkg.get_input_from_user(cmd_list=[]))
    brdpkg.tcl_execution()

def net_select():
    netsel.file_updation(netsel.tcl_write(netsel.spd_read(lst=[]),psicmds_lst = []))
    netsel.execute_cmd()

def porting_comp():
    portcomp.selected_nets()
    final_components = portcomp.get_components()
    cmds_lst=portcomp.tcl_write(final_components,psicmds_lst=[])

    portcomp.file_updation(cmds_lst)

    portcomp.execute_cmd()

    

def inside_loop():
    print("")
    print(Fore.YELLOW +"Net selection required? (yes or no) : "+ Style.RESET_ALL,end="")
    value1 = input().lower()
    if value1 == "yes":
        net_select()
        print("")
        while(1):
            porting_loop()
        print("Thank You!!")
        time.sleep(20)
        sys.exit()
    elif value1 == "no":
        print("Thank you!!")
        time.sleep(10)
        sys.exit()
    else:
        print("Please check and enter the input in (yes or no) format")

def porting_loop():
    print(Fore.YELLOW +"Porting for components required? (yes or no): "+ Style.RESET_ALL,end="")
    value2=input().lower()
    if value2=="yes":
        porting_comp()
        print("")
        print("Thank you!!")
        time.sleep(20)
        sys.exit()
    elif value2=="no":
        print("Thank you!!")
        time.sleep(10)
        sys.exit()
    else:
        print("Please check and enter the input in (yes or no) format")
        
def pi_process_automation():
    my_text_frame("                                         Welcome To PI Process Automation".splitlines())
    while(1):
        print("")
        print(Fore.YELLOW +"Board and Package file merge required ? (yes or no) : "+ Style.RESET_ALL,end="")
        value = input().lower()
        if value == "yes":
            brd_pkg()
            print("")
            while(1):
                inside_loop()
        elif value == "no":
            while(1):
               inside_loop()
        else:
            print("Please check and enter the input in (yes or no) format")
                
        

if __name__=="__main__": 
    pi_process_automation()
    print("")
    print("Thank You!!")
