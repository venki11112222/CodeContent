import os,re,sys,time
from colorama import Fore, Back, Style

print("The current working directory is:",os.getcwd())

# debug mode for developer
debug = False

#Variables
start="* Component description lines"
end=".CompCollection"
line1=""
line2=""

# PowerSI installed path on the local machine
powersi_path = "C:\\Cadence\\Sigrity2021.1\\tools\\bin\\PowerSI.exe"

def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(Fore.CYAN + Style.DIM + g_line + Style.RESET_ALL)
    for line in string_lst:
        print(Fore.CYAN + Style.DIM +"| {0:<{1}} |".format(line, width-4)+ Style.RESET_ALL)
    print(Fore.CYAN + Style.DIM + g_line + Style.RESET_ALL)
    

def selected_nets():
    my_text_frame("                                         PORT CREATION AT COMPONENTS".splitlines())
    global final_netlst
    final_netlst=[]
    try:
        with open("selected_nets.txt", 'r') as fp:
            data=fp.read()
            final_netlst = data.split()
            #print("The netlist we read from selected_nets text file is: ",final_netlst)
    except Exception as error:
        print("Error while opening the selected_nets.txt file", error)
        
    data=True
    while(data):
        print(Fore.YELLOW + Style.DIM + "The selected net list from phase2 netselection is: " + Style.RESET_ALL)
        for i in final_netlst:
            print(i)
        global ground_net
        ground_net = input(Fore.YELLOW + Style.DIM + "Enter the ground net name: " + Style.RESET_ALL).upper()
        if ground_net in final_netlst:
            final_netlst.remove(ground_net)
            data=False
        elif ground_net:
            ground_net = input(Fore.YELLOW + Style.DIM + "Select the ground net name correctly from netlist: " + Style.RESET_ALL).upper()
            if ground_net in final_netlst:
                final_netlst.remove(ground_net)
                data=False
        else:
            print("Empty Entered.Please check and select the ground net name from netlist: ")
            
    print(Fore.YELLOW + Style.DIM +"The final net list after removal of ground net is: "+ Style.RESET_ALL,final_netlst)

def get_components():
    try:
        data_lst=[]
        components=[]
        global spd_file_path
        spd_file_path = input(Fore.YELLOW + Style.DIM +"Enter the path for spd file: "+ Style.RESET_ALL)
        if (os.path.isfile(spd_file_path) and os.stat(spd_file_path).st_size != 0):
            with open(spd_file_path,'r') as fp:
                for line in fp:
                    #line.strip('\n')
                    if ".Connect" in line:
                        data_lst.append(re.sub(r'\n', '', line))
                        default_comp=("BRDC","PKGC")
                        for data in default_comp:
                            #if data in line:
                            if data in line.split()[1]:
                                value=True
                                while(value):
                                    line1 = next(fp)
                                    #line1.strip('\n')
                                    if ".EndC" not in line1:
                                        data_lst.append(re.sub(r'\n', '', line1))
                                    else:
                                        value=False
                                if debug:
                                    print("The component data from .spd is: ",data_lst)
                                    print("The no.of lines along with .connect to .Endc line is: ",len(data_lst))
                                if len(data_lst) == 3:
                                    for net in final_netlst:
                                        if net == data_lst[1].split("::")[1] and ground_net in data_lst[2]:
                                            if debug:
                                                print(Fore.YELLOW + Style.DIM +"THE COMPONENT AND MODELS FOR SELECTED NETS ARE:"+Style.RESET_ALL,data_lst[0].split()[1],data_lst[0].split()[2])
                                            #components.append((data_lst[0].split()[1],data_lst[0].split()[2]))
                                            components.append(data_lst[0].split()[1])
                                        elif ground_net in data_lst[1] and net == data_lst[2].split("::")[1]:
                                            if debug:
                                                print(Fore.YELLOW + Style.DIM +"THE COMPONENT AND MODELS FOR SELECTED NETS ARE:"+Style.RESET_ALL, data_lst[0].split()[1],
                                                  data_lst[0].split()[2])
                                            #components.append((data_lst[0].split()[1], data_lst[0].split()[2]))
                                            components.append(data_lst[0].split()[1])
                                data_lst=[]
            if debug:
                print("The final components are following: ",components)
            return components
        else:
            print(Fore.RED + Style.DIM + "Please provide valid spd file path or file might be empty"+ Style.RESET_ALL)
            time.sleep(15)
            sys.exit()
    except Exception as err:
        print(Fore.RED + Style.DIM + "Error Occurred.Please contact admin."+ Style.RESET_ALL)
        print(Fore.RED + Style.DIM + "Error details: "+ Style.RESET_ALL)
        print(err)

# Save Command
def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    print(Fore.YELLOW + Style.DIM + "File is Saved Successfullly:"+ Style.RESET_ALL)
    return cmd

"""
#Tickle script write
def tcl_write(final_components,psicmds_lst=[]):
    psicmds_lst.append("sigrity::open document {" + spd_file_path + "} {!}\n")
    psicmds_lst.append("sigrity::open window circuit {!}\n")
    for i in final_components:
        psicmds_lst.append("sigrity::select {" + i[0] + "} {!}\n")
        psicmds_lst.append("sigrity::update cktdef {"+ i[1] +"} -Definition {} -check {!}\n")
        psicmds_lst.append("sigrity::add port -circuit {"+ i[0] +"} {!}\n")
    psicmds_lst.append("sigrity::close window port {!}\n")
    psicmds_lst.append(cmd_save_file())
    return psicmds_lst
"""

# Tickle script write
def tcl_write(final_components,psicmds_lst=[]):
    psicmds_lst.append("sigrity::open document {" + spd_file_path + "} {!}\n")
    psicmds_lst.append("sigrity::open window circuit {!}\n")
    # sigrity::select {BRDC2039} {BRDC2040} {BRDC2041} {!}
    l1="sigrity::select "
    #sigrity::update circuit -manual {disable} {BRDC2039} {BRDC2040} {!}
    l2="sigrity::update circuit -manual {disable} "
    #sigrity::add port -circuit {BRDC2051} {BRDC2052} {BRDC2141} {!}
    l3="sigrity::add port -circuit "
    cnt=0
    for i in final_components:
        cnt+=1
        l1=l1+"{"+i+"} "
        l2=l2+"{"+i+"} "
        l3 = l3 + "{" + i + "} "

    l1 = l1 + "{!}\n"
    psicmds_lst.append(l1)
    l2 = l2 + "{!}\n"
    psicmds_lst.append(l2)
    l3 = l3 + "{!}\n"
    psicmds_lst.append(l3)
    psicmds_lst.append("sigrity::close window port {!}\n")
    psicmds_lst.append(cmd_save_file())
    if debug:
        print("The number of final_components are: ",cnt)
    return psicmds_lst

#tcl file update
def file_updation(cmds_lst):
    try:
        with open("porting.tcl", 'w') as fp:
            fp.writelines(cmds_lst)
        return True
    except Exception as error:
        print("Error while opening the net_select.tcl file", error)
        return False

#Execution of tcl file
def execute_cmd():
    print("")
    tcl_path=os.getcwd()
    if debug:
        print(Fore.YELLOW + Style.DIM +"The tcl file path is:"+ Style.RESET_ALL,tcl_path)
    tclfile_path = tcl_path + "\\porting.tcl"
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path
    print(Fore.GREEN+"Please wait!! Porting is in progress..."+Fore.RESET)
    os.system(execute_cmd)
    print(Fore.GREEN+"Ports are created successfully."+Fore.RESET)

if __name__=="__main__":
    selected_nets()
    final_components = get_components()
    print(Fore.YELLOW + Style.DIM +"The final components are following: "+Style.RESET_ALL, final_components)


    cmds_lst=tcl_write(final_components,psicmds_lst=[])

    file_updation(cmds_lst)

    execute_cmd()







