import os,sys,time,re
import colorama
from colorama import init,Fore, Back, Style
#import pandas as pd

#debug mode for developer
debug_mode=False
colorama.init()

# PowerSI installed path on the local machine
powersi_path = "C:\\Cadence\\Sigrity2021.1\\tools\\bin\\PowerSI.exe"


#Variables
start_netlist=".NetList"
end_netlist=".EndNetList"

def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(Fore.CYAN)
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width-4))
    print(g_line)
    print(Style.RESET_ALL)

#Reading of .spd file
def spd_read(lst=[]):
    try:
        my_text_frame("                                         NET SELECTION".splitlines())
        global spd_file_path
        colorama.init(autoreset=True)
        print(Fore.YELLOW +"Enter the path for spd file: "+ Style.RESET_ALL,end="")
        spd_file_path = input()
        if (os.path.isfile(spd_file_path)):
            with open(spd_file_path, 'r') as fp:
                for line in fp:
                    if start_netlist in line:
                        continue
                    elif "\t" in line:
                        if "::" in line:
                            lst.append(line.split("::")[0])
                        else:
                            lst.append(line.split()[0])
                    elif end_netlist in line:
                        break
            finalnet_lst = []
            cnt=0
            for value in lst[1:]:
                finalnet_lst.append(re.sub('\s+','', value))
                cnt+=1
            if debug_mode:
                print("The finalnet_lst is:",finalnet_lst)
            with open('NetList.txt', 'w') as f:
                f.write('\n'.join(finalnet_lst))
            '''
            df = pd.DataFrame()
            df['Nets Available'] = finalnet_lst[0::]
            df.to_excel('NetList.xlsx', index=False)
            '''
            if debug_mode:
                print("The total cnt of net lists are:",cnt)
            return finalnet_lst
        else:
            print(Fore.RED+"Please provide valid spd file path"+Fore.RESET)
            time.sleep(20)
            sys.exit()
    except Exception as err:
        print(Fore.RED+"Error Occurred.Please contact admin."+Fore.RESET)
        print(Fore.RED+"Error details: "+Fore.RESET)
        print(Fore.RED+ err +Fore.RESET)
        

        
#Save Command
def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd


#Tickle script write definition
def tcl_write(finalnet_lst,psicmds_lst = []):
    print(Fore.YELLOW +"Enter the required net list: "+ Style.RESET_ALL,end="")
    req_nets = input()
    req_netlist = req_nets.split(",")
    #print("The req_net lists are:", req_netlist)
    psicmds_lst.append("sigrity::open document {" + spd_file_path + "} {!}\n")
    
    psicmds_lst.append("sigrity::update net selected 0 -all {!}\n")
    """

    #sigrity::update net selected 0 -all {!}
    #sigrity::move net {PowerNets} {VCCGT} {!}
    #sigrity::update net selected 1 {+V_12P0_BUS_FILT_GPU} {!}

    #for i in Net_lst:
    #    if i:
    #        psicmds_lst.append("sigrity::update net selected 0 {" + i + "} {!}" + "\n")
    
    """
    unmatched_nets=[]
    matched_nets=[]
    print("")
    print(Fore.YELLOW+"Below are the selected nets: "+Fore.RESET)
    for i in req_netlist:
        if i in finalnet_lst:
            matched_nets.append(i)
            if i=='VSS':
                print(i)
                psicmds_lst.append("sigrity::update net selected 1 {" + i + "} {!}" + "\n")
                psicmds_lst.append("sigrity::move net {GroundNets} {" + i + "} {!}" + "\n")
            else:
                print(i)
                psicmds_lst.append("sigrity::update net selected 1 {" + i + "} {!}" + "\n")
                psicmds_lst.append("sigrity::move net {PowerNets} {" + i + "} {!}" + "\n")
        else:
            unmatched_nets.append(i)
    print("")
    print(Fore.YELLOW+"Below nets are not present in spd file: "+Fore.RESET)
    for i in unmatched_nets:
        print(i)
    value2=True
    while(value2):
        print("")
        print(Fore.RED +"would you like to proceed with above selected nets(yes or no): "+ Style.RESET_ALL,end="")
        value=input().lower()
        if value =="yes":
            print(Fore.YELLOW+"Proceeding with net selection"+Fore.RESET)
            value2=False
        elif value == "no":
            print("")
            print(Fore.YELLOW +"Enter the required net list to be added: "+ Style.RESET_ALL,end="")
            reentered_nets = input()
            reentered_netlist = reentered_nets.split(",")
            for i in reentered_netlist:
                if i in finalnet_lst:
                    matched_nets.append(i)
                    if i=='VSS':
                        print(i)
                        psicmds_lst.append("sigrity::update net selected 1 {" + i + "} {!}" + "\n")
                        psicmds_lst.append("sigrity::move net {GroundNets} {" + i + "} {!}" + "\n")
                    else:
                        print(i)
                        psicmds_lst.append("sigrity::update net selected 1 {" + i + "} {!}" + "\n")
                        psicmds_lst.append("sigrity::move net {PowerNets} {" + i + "} {!}" + "\n")
                else:
                    unmatched_nets.append(i)
            print("")
            print(Fore.YELLOW+"The selected nets are below:"+Fore.RESET)
            for i in matched_nets:
                print(i)
            print("")
            print(Fore.YELLOW+"Below nets not present in spd file:"+Fore.RESET)
            for j in unmatched_nets:
                print(j)
            value2=True
        try:
            with open("selected_nets.txt", 'w') as fp:
                for value in matched_nets:
                    fp.write(value)
                    fp.write('\n')
        except Exception as error:
            print(Fore.RED+"Error while opening the selected nets.txt file"+Fore.RESET, error)
    #save command
    psicmds_lst.append(cmd_save_file())
    return psicmds_lst
    
def execute_cmd():
    print("")
    #tcl_path=input("Enter the tcl file path: ")
    tcl_path=os.getcwd()
    if debug_mode:
        print("The tcl script file path is:",tcl_path)
    tclfile_path=tcl_path+"\\netselection.tcl"
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path
    print(Fore.GREEN+"Please wait!! Net Selection is in progress..."+Fore.RESET)
    os.system(execute_cmd)
    print(Fore.GREEN+"Net Selection was completed successfully."+Fore.RESET)


def file_updation(psicmds_lst):
    try:
        with open("netselection.tcl", 'w') as fp:
            fp.writelines(psicmds_lst)
        return True
    except Exception as error:
        print(Fore.RED+"Error while opening the net_select.tcl file"+Fore.RESET,error)
        return False

if __name__=="__main__":
    file_updation(tcl_write(spd_read(lst=[]),psicmds_lst = []))
    
    execute_cmd()


