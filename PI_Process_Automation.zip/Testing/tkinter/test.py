
from tkinter import *
from tkinter import ttk, filedialog
from tkinter.filedialog import askopenfile
import os, sys,time

# debug mode for developer
debug_mode = False

# PowerSI installed path on the local machine
powersi_path = "C:\\Cadence\\Sigrity2021.1\\tools\\bin\\PowerSI.exe"

mw=Tk()
mw.geometry("400x200")
#mainwindow.iconbitmap("images/shop.png")
#mw.grid_columnconfigure((0,4), weight=1)
mw.title("Welcome Note")

#FUCNTION DEFINITIONS
def tgz_file():
   file = filedialog.askopenfile(mode='r')
   if file:
      global tgz_file_path
      tgz_file_path = os.path.abspath(file.name)
      Label(mw, text="The tgz file path is: " + str(tgz_file_path), font=('Aerial 11')).grid(row=9,sticky=W)

def stkup_file():
   file = filedialog.askopenfile(mode='r')
   if file:
      global stkup_file_path
      stkup_file_path = os.path.abspath(file.name)
      Label(mw, text="The stkup file path is : " + str(stkup_file_path), font=('Aerial 11')).grid(row=10,sticky=W)

def brd_file():
   file = filedialog.askopenfile(mode='r')
   if file:
      global brd_file_path
      brd_file_path = os.path.abspath(file.name)
      Label(mw, text="The brd file path is: " + str(brd_file_path), font=('Aerial 11')).grid(row=11,sticky=W)


def Solderball_values():
   global Height_value,Radius_value
   Label(mw, text="Solder Ball height and radius is Submitted : "+ str(Entry7.get())+","+ str(Entry8.get()), font=('Aerial 11')).grid(row=12, sticky=W)
   Height_value=Entry7.get()
   #print(Entry7.get())
   print(Height_value)
   Radius_value=Entry8.get()
   #print(Entry8.get())
   print(Radius_value)

#PHASE1 CODE
# Key variables
oldckt = "oldckt"
newckt = "newckt"
s_ball = "s_ball"
pkg = "pkg"
measurement = "measurement"
pkgpcb = "pkg&pcb"

# variables values
oldckt_value = "BRDU1"
newckt_value = "PKGA1"
s_ball_value = "SolderBall"
pkg_value = "InheritPkg"
measurement_value = "mm"
pkgpcb_value = "PKG&PCB"

# dict for cmd_import_pkg
pkg_import_data = {oldckt: oldckt_value, newckt: newckt_value, s_ball: s_ball_value, pkg: pkg_value, measurement:measurement_value, pkgpcb: pkgpcb_value}


def cmd_open_pkd_tgz(tgz_path):
    cmd = "sigrity::open document {" + tgz_path + "} {!}\n"
    return cmd


def cmd_import_stkup(stkup_file_path):
    cmd = "sigrity::import stackup {" + stkup_file_path + "} {!}\n"
    return cmd


def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd


def close_pkg_file():
    cmd = "sigrity::close document {!} \n"
    return cmd


def cmd_open_brd(brd_file_path):
    cmd = "sigrity::open document {" + brd_file_path + "} {!}\n"
    return cmd
   
def cmd_import_pkg(pkg_import_data):
    '''
    pkg_import_data["spd_path_value"]- path of spd file
    pkg_import_data["Height_value"]- solder ball height
    pkg_import_data["Radius_value"]-solder ball radius

    Example: 
    import PKG -SPDFile {E:/Share/VakulabharanamX/pkg_and_brd_files/pkg_file/dg256eu_ww45p3_pisimulation.spd} -OldCkt {BRDU1} 
    -NewCkt {PKGA1} -method {SolderBall} -MatchSel {InheritPkg} -unit {mm} -height {4.7264e-02} -radius {2.4498e-02} -Prefix -ApplyTo {PKG&PCB} {!}

    '''
    cmd = r"sigrity::import PKG -SPDFile {" + pkg_import_data["spd_path_value"] + "} -OldCkt {" + pkg_import_data[oldckt] + "} -NewCkt {" + \
          pkg_import_data[newckt] + "} -method {" + pkg_import_data[s_ball] + "} -MatchSel {" + pkg_import_data[pkg] + "} -unit {" + pkg_import_data[measurement] + "} -height {" + \
          pkg_import_data["Height_value"] + "} -radius {" + pkg_import_data["Radius_value"] + "} -Prefix -ApplyTo {" + pkg_import_data[pkgpcb] + "} {!}" + "\n"
    if debug_mode:
        print("The import package path is:", cmd)
    return cmd


def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd

def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width-4))
    print(g_line)
    
def file_updation(cmd_list):
    try:
        with open("brd_pkg_merge.tcl", 'w') as file:
            file.writelines(cmd_list)
        return True
    except Exception as err:
        print("Error while opening file brd_pkg_merge.tcl",err)
        return False
      
def get_input_from_user(cmd_list=[]):
    try:
        my_text_frame("                                         BOARD AND PACKAGE FILE MERGE".splitlines())
        tgz_file_path
        if (os.path.isfile(tgz_file_path)):
            cmd_list.append(cmd_open_pkd_tgz(tgz_file_path))
        else:
            print("Please recheck the entered path and .tgz file present or not")
            time.sleep(30)
            sys.exit()
        #.spd file path
        pkg_import_data["spd_path_value"] = tgz_file_path[0:-3] + "spd"

        stkup_file_path
        if (os.path.isfile(stkup_file_path)):
            cmd_list.append(cmd_import_stkup(stkup_file_path))
        else:
            print("Please recheck the entered path and .csv file present or not")
            time.sleep(30)
            sys.exit()

        #Saving the file
        cmd_list.append(cmd_save_file())

        #Closing of package file
        cmd_list.append(close_pkg_file())

        brd_file_path
        if (os.path.isfile(brd_file_path)):
            cmd_list.append(cmd_open_brd(brd_file_path))
        else:
            print("Please recheck the entered path and .brd file present or not")
            time.sleep(30)
            sys.exit()
            
        Height_value
        if Height_value=='':
            print("Please check the entered solderball height")
            time.sleep(30)
            sys.exit()
        else:
            pkg_import_data["Height_value"] = Height_value

        Radius_value
        if Radius_value=='':
            print("Please check the entered solderball radius")
            time.sleep(30)
            sys.exit()
        else:
            pkg_import_data["Radius_value"] = Radius_value 
        
        cmd_list.append(cmd_import_pkg(pkg_import_data))
        cmd_list.append(cmd_save_file())
        return cmd_list
    except Exception as error:
        print("The Error raised from get_input_from_user function is:",error)

def execute_cmd(tclfile_path):
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path

    if debug_mode:
        print("The command executing is:", execute_cmd)
    print("Please wait!! Files are processing to merge...")
    os.system(execute_cmd)
    print("Board and Package files are merged.")
    time.sleep(30)
    sys.exit()
    

def tcl_execution():
    tcl_path = os.getcwd()
    if debug_mode:
        print("The tcl script file path is: ",tcl_path)
    tclfile_path =tcl_path + "\\brd_pkg_merge.tcl"
    execute_cmd(tclfile_path)



#MAIN FUNCTION CALL FROM BUTTION EXECUTE MERGE
def phase1_exe():
   file_updation(get_input_from_user(cmd_list=[]))
   tcl_execution()

#Label Display
label1=Label(mw,text="Welcome to PI Process Automation",font=('Arial',14),bd=1,relief="sunken",padx=10,pady=10,fg='blue')
Label3 = Label(mw, text="Package File:")
Label4 = Label(mw, text="Stackup File:")
Label5 = Label(mw, text="Board File:")
Label6=Label(mw,text="Solder Ball Dimensions",font=('Arial',14),bd=1,relief="sunken",padx=10,pady=10,fg='blue')
Label7=Label(mw,text="Radius:")
Label8=Label(mw,text="Height:")
Label9=Label(mw,text="      ")


#ENTRY FORMS
Entry3 = Entry(mw)
Entry4 = Entry(mw)
Entry5 = Entry(mw)
Entry7 = Entry(mw)
Entry8 = Entry(mw)

#BUTTON CREATION

btn1=Button(mw,text='...',font=('Arial',14),command=tgz_file)
btn2=Button(mw,text='...',font=('Arial',14),command=stkup_file)
btn3=Button(mw,text='...',font=('Arial',14),command=brd_file)
btn4=Button(mw,text='submit',font=('Arial',14),command=Solderball_values)
btn=Button(mw,text='Execute Merge',font=('Arial',14),bg='cyan',command=phase1_exe)

#WIDGETS DISPLAY
label1.grid(row=0,column=0,columnspan=6,sticky=W+E)
Label3.grid(row=1, column=0,sticky=W)
Entry3.grid(row=1, column=1,sticky='ew',ipadx=100,pady=10)
btn1.grid(row=1,column = 2,sticky="ew",padx=20)
Label4.grid(row=2, column=0,sticky=W)
Entry4.grid(row=2, column=1,sticky='ew',pady=10)
btn2.grid(row=2,column = 2,sticky="ew",padx=20)
Label5.grid(row=3, column=0,sticky=W)
Entry5.grid(row=3, column=1, sticky="ew",pady=10)
btn3.grid(row=3,column = 2,sticky="ew",padx=20)
Label6.grid(row=4,column=0,columnspan=3,sticky=W+E)
Label7.grid(row=6,column=0)
Entry7.grid(row=6,column=1,sticky=W)
Label8.grid(row=7,column=0)
Entry8.grid(row=7,column=1,sticky=W)
btn4.grid(row=7,column = 3)
btn.grid(row=7,column=4,padx=5,pady=5)

exit_button = Button(mw, text="Exit", command=mw.quit)
exit_button.grid(row=8,column=3,padx=5,pady=5)




mw.mainloop()

