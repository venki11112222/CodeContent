from tkinter import *
from tkinter import ttk
from tkinter import ttk, filedialog
from tkinter.filedialog import askopenfile
import os,sys,time,re

# debug mode for developer
debug_mode = False

# PowerSI installed path on the local machine
powersi_path = "C:\\Cadence\\Sigrity2021.1\\tools\\bin\\PowerSI.exe"

mw=Tk()
mw.geometry("800x550")

my_notebook=ttk.Notebook(mw)
my_notebook.pack(pady=15)

frame1=Frame(my_notebook,width=600,height=450)
frame2=Frame(my_notebook,width=600,height=450)

frame1.pack(fill="both",expand=1)
frame2.pack(fill="both",expand=1)

my_notebook.add(frame1,text="FirstTab")
my_notebook.add(frame2,text="SecondTab")

#PHASE1 TKINTER CODE
def tgz_file():
   #mw.filename=filedialog.askopenfile(mode='r')
   #my_label=Label(mw,text=mw.filename).grid(row=1, column=1,sticky='ew',ipadx=100,pady=10)
   file = filedialog.askopenfile(mode='r')
   if file:
      global tgz_file_path
      tgz_file_path = os.path.abspath(file.name)
      Label(frame1, text=str(tgz_file_path), font=('Aerial 11')).grid(row=1, column=1,sticky='ew',ipadx=10,pady=10)
"""
def pkg_file():
   file = filedialog.askopenfile(mode='r')
   if file:
      global pkg_file_path
      pkg_file_path = os.path.abspath(file.name)
      Label(frame1, text=str(pkg_file_path), font=('Aerial 11')).grid(row=2, column=1,sticky='ew',pady=10)
"""
def brd_file():
   file = filedialog.askopenfile(mode='r')
   if file:
      global brd_file_path
      brd_file_path = os.path.abspath(file.name)
      Label(frame1, text=str(brd_file_path), font=('Aerial 11')).grid(row=2, column=1,sticky='ew',pady=10)

def stkup_file():
   file = filedialog.askopenfile(mode='r')
   if file:
      global stkup_file_path
      stkup_file_path = os.path.abspath(file.name)
      Label(frame1, text=str(stkup_file_path), font=('Aerial 11')).grid(row=3, column=1, sticky="ew",pady=10)

def Solderball_values():
   global Height_value,Radius_value
   Label(frame1, text="Solder Ball height and radius is Submitted : "+ str(Entry7.get())+","+ str(Entry8.get()), font=('Aerial 11')).grid(row=12, sticky=W)
   #print(Entry7.get())
   Height_value=Entry7.get()
   #print(Entry8.get())
   Radius_value=Entry8.get()
   

#PHASE1 CODE
# Key variables
oldckt = "oldckt"
newckt = "newckt"
s_ball = "s_ball"
pkg = "pkg"
measurement = "measurement"
pkgpcb = "pkg&pcb"

# variables values
oldckt_value = "BRDU1"
newckt_value = "PKGA1"
s_ball_value = "SolderBall"
pkg_value = "InheritPkg"
measurement_value = "mm"
pkgpcb_value = "PKG&PCB"

# dict for cmd_import_pkg
pkg_import_data = {oldckt: oldckt_value, newckt: newckt_value, s_ball: s_ball_value, pkg: pkg_value, measurement:measurement_value, pkgpcb: pkgpcb_value}


def cmd_open_pkd_tgz(tgz_path):
    cmd = "sigrity::open document {" + tgz_path + "} {!}\n"
    return cmd


def cmd_import_stkup(stkup_file_path):
    cmd = "sigrity::import stackup {" + stkup_file_path + "} {!}\n"
    return cmd


def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd


def close_pkg_file():
    cmd = "sigrity::close document {!} \n"
    return cmd


def cmd_open_brd(brd_file_path):
    cmd = "sigrity::open document {" + brd_file_path + "} {!}\n"
    return cmd
   
def cmd_import_pkg(pkg_import_data):
    '''
    pkg_import_data["spd_path_value"]- path of spd file
    pkg_import_data["Height_value"]- solder ball height
    pkg_import_data["Radius_value"]-solder ball radius

    Example: 
    import PKG -SPDFile {E:/Share/VakulabharanamX/pkg_and_brd_files/pkg_file/dg256eu_ww45p3_pisimulation.spd} -OldCkt {BRDU1} 
    -NewCkt {PKGA1} -method {SolderBall} -MatchSel {InheritPkg} -unit {mm} -height {4.7264e-02} -radius {2.4498e-02} -Prefix -ApplyTo {PKG&PCB} {!}

    '''
    cmd = r"sigrity::import PKG -SPDFile {" + pkg_import_data["spd_path_value"] + "} -OldCkt {" + pkg_import_data[oldckt] + "} -NewCkt {" + \
          pkg_import_data[newckt] + "} -method {" + pkg_import_data[s_ball] + "} -MatchSel {" + pkg_import_data[pkg] + "} -unit {" + pkg_import_data[measurement] + "} -height {" + \
          pkg_import_data["Height_value"] + "} -radius {" + pkg_import_data["Radius_value"] + "} -Prefix -ApplyTo {" + pkg_import_data[pkgpcb] + "} {!}" + "\n"
    if debug_mode:
        print("The import package path is:", cmd)
    return cmd


def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd

def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width-4))
    print(g_line)
    
def file_updation(cmd_list):
    try:
        with open("brd_pkg_merge.tcl", 'w') as file:
            file.writelines(cmd_list)
        return True
    except Exception as err:
        print("Error while opening file brd_pkg_merge.tcl",err)
        return False
      
def get_input_from_user(cmd_list=[]):
    try:
        my_text_frame("                                         BOARD AND PACKAGE FILE MERGE".splitlines())
        tgz_file_path
        if (os.path.isfile(tgz_file_path)):
            cmd_list.append(cmd_open_pkd_tgz(tgz_file_path))
        else:
            print("Please recheck the entered path and .tgz file present or not")
            time.sleep(30)
            sys.exit()
        #.spd file path
        pkg_import_data["spd_path_value"] = tgz_file_path[0:-3] + "spd"

        stkup_file_path
        if (os.path.isfile(stkup_file_path)):
            cmd_list.append(cmd_import_stkup(stkup_file_path))
        else:
            print("Please recheck the entered path and .csv file present or not")
            time.sleep(30)
            sys.exit()

        #Saving the file
        cmd_list.append(cmd_save_file())

        #Closing of package file
        cmd_list.append(close_pkg_file())

        brd_file_path
        if (os.path.isfile(brd_file_path)):
            cmd_list.append(cmd_open_brd(brd_file_path))
        else:
            print("Please recheck the entered path and .brd file present or not")
            time.sleep(30)
            sys.exit()
            
        Height_value
        if Height_value=='':
            print("Please check the entered solderball height")
            time.sleep(30)
            sys.exit()
        else:
            pkg_import_data["Height_value"] = Height_value

        Radius_value
        if Radius_value=='':
            print("Please check the entered solderball radius")
            time.sleep(30)
            sys.exit()
        else:
            pkg_import_data["Radius_value"] = Radius_value 
        
        cmd_list.append(cmd_import_pkg(pkg_import_data))
        cmd_list.append(cmd_save_file())
        return cmd_list
    except Exception as error:
        print("The Error raised from get_input_from_user function is:",error)

def execute_cmd(tclfile_path):
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path
    if debug_mode:
        print("The command executing is:", execute_cmd)
    print("Please wait!! Files are processing to merge...")
    os.system(execute_cmd)
    print("Board and Package files are merged.")
    time.sleep(30)
    sys.exit()
    

def tcl_execution():
    tcl_path = os.getcwd()
    if debug_mode:
        print("The tcl script file path is: ",tcl_path)
    tclfile_path =tcl_path + "\\brd_pkg_merge.tcl"
    execute_cmd(tclfile_path)



#MAIN FUNCTION CALL FROM BUTTION EXECUTE MERGE
def phase1_exe():
   file_updation(get_input_from_user(cmd_list=[]))
   tcl_execution()

#Label Display
label1=Label(frame1,text="Welcome to PI Process Automation",font=('Arial',14),bd=1,
             relief="sunken",padx=150,pady=10,fg='dark slate blue',bg='ghost white')
Label3 = Label(frame1, text="Package File:",font=('Arial',12))
Label4 = Label(frame1, text="BoardFile:",font=('Arial',12))
Label5 = Label(frame1, text="Package Stackup:",font=('Arial',12))
#Label11=label(frame1, text="
Label6=Label(frame1,text="Solder Ball Dimensions",font=('Arial',14),bd=1,
             relief="sunken",padx=202,pady=10,fg='dark slate blue',bg='ghost white')
Label7=Label(frame1,text="Radius:",font=('Arial',12))
Label8=Label(frame1,text="Height:",font=('Arial',12))
Label9=Label(frame1,text="      ",font=('Arial',14))
Label10 = Label(frame1,text="      ",font=('Arial',14))


#ENTRY FORMS
Entry3 = Entry(mw)
Entry4 = Entry(mw)
Entry5 = Entry(mw)
Entry7 = Entry(frame1)
Entry8 = Entry(frame1)

#BUTTON CREATION

btn1=Button(frame1,text='...',font=('Arial',14),command=tgz_file)
btn2=Button(frame1,text='...',font=('Arial',14),command=brd_file)
btn3=Button(frame1,text='...',font=('Arial',14),command=stkup_file)
btn4=Button(frame1,text='submit',font=('Arial',14),fg="green",bg='floral white',command=Solderball_values)
btn=Button(frame1,text='Execute Merge',font=('Arial',14),fg="green",bg='floral white',command=phase1_exe)

"""
#WIDGETS DISPLAY
label1.grid(row=0,column=0,columnspan=8,sticky=W+E)
Label3.grid(row=1, column=0,sticky=W)
#Entry3.grid(row=1, column=1,sticky='ew',ipadx=100,pady=10)
#my_label.grid(row=1, column=1,sticky='ew',ipadx=100,pady=10)
btn1.grid(row=1,column = 2,sticky="ew",padx=20)
Label4.grid(row=2, column=0,sticky=W)
#Entry4.grid(row=2, column=1,sticky='ew',pady=10)
btn2.grid(row=2,column = 2,sticky="ew",padx=20)
Label5.grid(row=3, column=0,sticky=W)
#Entry5.grid(row=3, column=1, sticky="ew",pady=10)
btn3.grid(row=3,column = 2,sticky="ew",padx=20)
Label6.grid(row=4,column=0,columnspan=3,sticky=W+E)
Label7.grid(row=6,column=0)
Entry7.grid(row=6,column=1,sticky=W)
Label8.grid(row=7,column=0)
Entry8.grid(row=7,column=1,sticky=W)
btn4.grid(row=7,column = 3)
btn.grid(row=7,column=4,padx=5,pady=5)
"""

#UPDATED WIDGETS DISPLAY
label1.grid(row=0,column=0,columnspan=10,sticky=W+E)
Label3.grid(row=1, column=0,sticky=E)
btn1.grid(row=1,column = 2,sticky="w",padx=20)
Label4.grid(row=2, column=0,sticky=E)
btn2.grid(row=2,column = 2,sticky="w",padx=20)
Label5.grid(row=3, column=0,sticky=E)
btn3.grid(row=3,column = 2,sticky="w",padx=20)

#SolderBallDimension
Label9.grid(row=4,column=0)
Label6.grid(row=5,column=0,columnspan=3,sticky=W+E)
Label7.grid(row=7,column=0,sticky=E)
Entry7.grid(row=7,column=1,sticky=W+E,padx=30)
Label8.grid(row=8,column=0,sticky=E)
Entry8.grid(row=8,column=1,sticky=W+E,padx=30)

#to add space
Label10.grid(row=9,column=0)

#submit and Exceute button
btn4.grid(row=10,column = 0,sticky=E,pady=10)
btn.grid(row=10,column=1,sticky=E)



#PHASE2 TKINTER CODE

label1=Label(frame2,text="Welcome to PI Process Automation",font=('Arial',14),bd=1,relief="sunken",padx=10,pady=10,fg='blue')
label1.grid(row=0,column=0,columnspan=8,sticky=W+E)

label3 = Label(frame2, text="SPD File Path:")
label3.grid(row=1,column=0,sticky=W)

#label4 = Label(frame2, text="TCL File Path:")
#label4.grid(row=7,column=0,sticky=W)

def spd_file():
   file = filedialog.askopenfile(mode='r')
   if file:
      global spd_file_path
      spd_file_path = os.path.abspath(file.name)
      Label(frame2, text=str(spd_file_path), font=('Aerial 11')).grid(row=2, column=0,sticky='ew',ipadx=10,pady=10)

#global tcl_path
#tcl_path=Entry(frame2,width=20,font=('Arial',18))
#tcl_path.grid(row=7, column=1,sticky='ew',ipadx=10,pady=10)

spd_button=Button(frame2,text='...',font=('Arial',14),command=spd_file)
spd_button.grid(row=2,column =2,sticky="ew",padx=10,pady=10)


yscrollbar = Scrollbar(frame2,orient=VERTICAL)
yscrollbar.grid(row=3,column=1,sticky='ns')

list_box=Listbox(frame2,width=50, height=20,selectmode="multiple",yscrollcommand=yscrollbar.set)
list_box.grid(row=3,column=0,padx=10)
list_box.insert(END,"Below is the NET List: ")
list_box1=Listbox(frame2,selectmode="multiple",yscrollcommand=yscrollbar.set)
list_box1.grid(row=3,column=3,padx=10)
# Attach listbox to vertical scrollbar
yscrollbar.config(command=list_box.yview)
list_box.insert(END,"Venkat try until you get")



exit_button = Button(frame2, text="Exit", command=frame2.quit)
exit_button.grid(row=4)


#Phase2 FUNCTION DEFINITION
def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width-4))
    print(g_line)

#Variables
start_netlist=".NetList"
end_netlist=".EndNetList"

def execute_cmd2():
    print("VENKAT BOY TRY UNTIL YOU GET IT")
    #tcl_path=input("Enter the tcl file path: ")
    tcl_path=os.getcwd()
    if debug_mode:
        print("The tcl script file path is:",tcl_path)
    tclfile_path=tcl_path+"\\netselection.tcl"
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path
    print("Please wait!! Net Selection is in progress...")
    os.system(execute_cmd)
    print("Net Selection was completed successfully.")

#Selection of NETS from list_box
global final_lst_data
def net_lists():
   final_lst_data=[]
   for i in list_box.curselection():
      name=list_box.get(i)
      final_lst_data.append(name)
   for i in final_lst_data:
      list_box1.insert(END,i)
   #time.sleep(20)
   print('The selected net lists are following:', final_lst_data)
   try:
      with open("selected_nets.txt", 'w') as fp:
         for value in final_lst_data:
            fp.write(value)
            fp.write('\n')
   except Exception as error:
      print("Error while opening the selected nets.txt file", error)
                                                                                                                                     
#Tickle script write definition
   psicmds_lst = []
   psicmds_lst.append("sigrity::open document {" + spd_file_path + "} {!}\n")
    
   psicmds_lst.append("sigrity::update net selected 0 -all {!}\n")
   for i in final_lst_data:
      if i=='VSS':
         print("1",i)
         psicmds_lst.append("sigrity::update net selected 1 {" + i + "} {!}" + "\n")
         psicmds_lst.append("sigrity::move net {GroundNets} {" + i + "} {!}" + "\n")
      else:
         print("2",i)
         psicmds_lst.append("sigrity::update net selected 1 {" + i + "} {!}" + "\n")
         psicmds_lst.append("sigrity::move net {PowerNets} {" + i + "} {!}" + "\n")
   psicmds_lst.append(cmd_save_file())
   try:
      with open("netselection.tcl", 'w') as fp:
         fp.writelines(psicmds_lst)
         #return True
   except Exception as error:
      print("Error while opening the net_select.tcl file",error)
      #return False
   print("VENKAT BOY TRY UNTIL YOU GET IT")
   #tcll_path=tcl_path.get()
   #print("THE TCL PATH IS: ",tcl_path)
   tcl_path=os.getcwd()
   print("THE TCL PATH IS: ",tcl_path)
   if debug_mode:
      print("The tcl script file path is:",tcll_path)
   tclfile_path=tcl_path+"\\netselection.tcl"
   execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path
   print("Please wait!! Net Selection is in progress...")
   os.system(execute_cmd)
   print("Net Selection was completed successfully.")
   
#Reading of .spd file
def spd_read(lst=[]):
    try:
        my_text_frame("                                         NET SELECTION".splitlines())
        global spd_file_path
        spd_file_path
        if (os.path.isfile(spd_file_path)):
            with open(spd_file_path, 'r') as fp:
                for line in fp:
                    if start_netlist in line:
                        continue
                    elif "\t" in line:
                        if "::" in line:
                            lst.append(line.split("::")[0])
                        else:
                            lst.append(line.split()[0])
                    elif end_netlist in line:
                        break
            global finalnet_lst
            finalnet_lst = []
            cnt=0
            print("VENKATESH CHECK-1",lst)
            for value in lst[1:]:
                finalnet_lst.append(re.sub('\s+','', value))
                cnt+=1
            if debug_mode:
                print("The finalnet_lst is:",finalnet_lst)
            with open('NetList.txt', 'w') as f:
                f.write('\n'.join(finalnet_lst))
            '''
            df = pd.DataFrame()
            df['Nets Available'] = finalnet_lst[0::]
            df.to_excel('NetList.xlsx', index=False)
            '''
            if debug_mode:
                print("The total cnt of net lists are:",cnt)
            #INSERTING NETS INTO LIST_BOX
            #for net in finalnet_lst:
            #   list_box.insert(END,net)
            print("THE FINALNET_LIST ARE FOLLOWING: ",finalnet_lst)
            return finalnet_lst
        else:
            print("Please provide valid spd file path")
            sys.exit()
    except Exception as err:
        print("Error Occurred.Please contact admin.")
        print("Error details: ")
        print(err)
        
def lstbox2():
   selected_data=[]  
   for i in list_box1.curselection():
      name=list_box.get(i)
      selected_data.append(name)
      print("THE SELECTED NETS 1 ARE FOLLOWING: ",selected_data)
   print("THE SELECTED NETS 2 ARE FOLLOWING: ",selected_data)
   return selected_data


#MAIN FUNCTION CALL FROM BUTTION EXECUTE MERGE
def phase2_exe():
   global main_lst
   main_lst=spd_read(lst=[])
   for net in main_lst:
      list_box.insert(END,net)
   btn=Button(frame2,text="NetSelection",command=net_lists)
   btn.grid(row=5)
#def phase2_1_exe():
#   file_updation1(tcl_write(main_lst,psicmds_lst = []))
#  execute_cmd()
   
main_button=Button(frame2,text='Read_SPD_FILE',font=('Arial',14),bg='cyan',command=phase2_exe)
main_button.grid(row=6)

#main_button=Button(frame2,text='Net Selection',font=('Arial',14),bg='cyan',command=phase2_1_exe)
#main_button.grid(row=7)

mw.mainloop()

