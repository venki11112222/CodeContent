'''
Board and Package File merge
'''


import os, re, sys, time,colorama
from colorama import Fore, Back, Style
import openpyxl
from openpyxl import Workbook
from colorama import init,Fore, Back, Style
#colorama.init()


# debug mode for developer
debug_mode = False

# PowerSI installed path on the local machine
powersi_path = "C:\\Cadence\\Sigrity2021.1\\tools\\bin\\PowerSI.exe"
os.chdir(r'E:\Automation_Team\Venkatesh\Testing\Phase4\Test_Phase4\Files')


# Key variables
oldckt = "oldckt"
newckt = "newckt"
s_ball = "s_ball"
pkg = "pkg"
measurement = "measurement"
pkgpcb = "pkg&pcb"

# variables values
oldckt_value = "BRDU1"
newckt_value = "PKGA1"
s_ball_value = "SolderBall"
pkg_value = "InheritPkg"
measurement_value = "mm"
pkgpcb_value = "PKG&PCB"

# dict for cmd_import_pkg
pkg_import_data = {oldckt: oldckt_value, newckt: newckt_value, s_ball: s_ball_value, pkg: pkg_value, measurement:measurement_value, pkgpcb: pkgpcb_value}

def cmd_open_pkd_tgz(tgz_path):
    cmd = "sigrity::open document {" + tgz_path + "} {!}\n"
    return cmd


def cmd_import_stkup(stkup_path):
    cmd = "sigrity::import stackup {" + stkup_path + "} {!}\n"
    return cmd

def cmd_import_material_lib(mat_path):
    cmd = "sigrity::import material {" + mat_path + "} {!}\n"
    return cmd

def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd


def close_pkg_file():
    cmd = "sigrity::close document {!} \n"
    return cmd


def cmd_open_brd(brd_file_path):
    cmd = "sigrity::open document {" + brd_file_path + "} {!}\n"
    return cmd


def cmd_import_pkg(pkg_import_data):
    '''
    pkg_import_data["spd_path_value"]- path of spd file
    pkg_import_data["Height_value"]- solder ball height
    pkg_import_data["Radius_value"]-solder ball radius

    Example: 
    import PKG -SPDFile {E:/Share/VakulabharanamX/pkg_and_brd_files/pkg_file/dg256eu_ww45p3_pisimulation.spd} -OldCkt {BRDU1} 
    -NewCkt {PKGA1} -method {SolderBall} -MatchSel {InheritPkg} -unit {mm} -height {4.7264e-02} -radius {2.4498e-02} -Prefix -ApplyTo {PKG&PCB} {!}

    '''
    cmd = r"sigrity::import PKG -SPDFile {" + pkg_import_data["spd_path_value"] + "} -OldCkt {" + pkg_import_data[oldckt] + "} -NewCkt {" + \
          pkg_import_data[newckt] + "} -method {" + pkg_import_data[s_ball] + "} -MatchSel {" + pkg_import_data[pkg] + "} -unit {" + pkg_import_data[measurement] + "} -height {" + \
          pkg_import_data["Height_value"] + "} -radius {" + pkg_import_data["Radius_value"] + "} -Prefix -ApplyTo {" + pkg_import_data[pkgpcb] + "} {!}" + "\n"
    if debug_mode:
        print("The import package path is:", cmd)
    return cmd


def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd


def file_updation1(cmd_list):
    try:
        with open("brd_pkg_merge.tcl", 'w') as file:
            file.writelines(cmd_list)
        return True
    except Exception as err:
        print("Error while opening file brd_pkg_merge.tcl",err)
        return False


def execute_cmd1(tclfile_path):
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path

    if debug_mode:
        print("The command executing is:", execute_cmd)
    print("Please wait!! Files are processing to merge...")
    os.system(execute_cmd)
    print("Board and Package files are merged.")


def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width-4))
    print(g_line)

def get_input_from_user(cmd_list=[]):
    try:
        my_text_frame("                                         BOARD AND PACKAGE FILE MERGE".splitlines())
        tgz_path = input("Enter the pakage(tgz) file path: ")
        if (os.path.isfile(tgz_path)):
            cmd_list.append(cmd_open_pkd_tgz(tgz_path))
        else:
            print("Please recheck the entered path and .tgz file present or not")
            time.sleep(30)
            sys.exit()
        #.spd file path
        pkg_import_data["spd_path_value"] = tgz_path[0:-3] + "spd"


        #Saving the file
        cmd_list.append(cmd_save_file())

        #Closing of package file
        cmd_list.append(close_pkg_file())

        brd_file_path = input("Enter the Board file path: ")
        if (os.path.isfile(brd_file_path)):
            cmd_list.append(cmd_open_brd(brd_file_path))
        else:
            print("Please recheck the entered path and .brd file present or not")
            time.sleep(30)
            sys.exit()
            
        Height_value=input("Enter the solderball height: ")
        if Height_value=='':
            print("Please check the entered solderball height")
            time.sleep(30)
            sys.exit()
        else:
            pkg_import_data["Height_value"] = Height_value

        Radius_value=input("Enter the solderball radius: ")
        if Radius_value=='':
            print("Please check the entered solderball radius")
            time.sleep(30)
            sys.exit()
        else:
            pkg_import_data["Radius_value"] = Radius_value 
        
        cmd_list.append(cmd_import_pkg(pkg_import_data))
        cmd_list.append(cmd_save_file())
        
        stkup_path = input("Enter the stackup file path: ")
        if (os.path.isfile(stkup_path)):
            cmd_list.append(cmd_import_stkup(stkup_path))
        else:
            print("Please recheck the entered path and .csv file present or not")
            time.sleep(30)
            sys.exit()

        mat_path = input("Enter the material file path: ")
        if (os.path.isfile(mat_path)):
            cmd_list.append(cmd_import_material_lib(mat_path))
        else:
            print("Please recheck the entered path and .txt file present or not")
            time.sleep(30)
            sys.exit()
            
        cmd_list.append(cmd_save_file())
        return cmd_list
    except Exception as error:
        print("The Error raised from get_input_from_user function is:",error)


def tcl_execution():
    tcl_path = os.getcwd()
    if debug_mode:
        print("The tcl script file path is: ",tcl_path)
    tclfile_path =tcl_path + "\\brd_pkg_merge.tcl"
    execute_cmd1(tclfile_path)


#PHASE 2 NET SELECTION CODE

#Variables
start_netlist=".NetList"
end_netlist=".EndNetList"

def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width-4))
    print(g_line)

#Reading of .spd file
def spd_read(lst=[]):
    try:
        my_text_frame("                                         NET SELECTION".splitlines())
        global spd_file_path
        spd_file_path = input("Enter the path for spd file: ")
        if (os.path.isfile(spd_file_path)):
            with open(spd_file_path, 'r') as fp:
                for line in fp:
                    if start_netlist in line:
                        continue
                    elif "\t" in line:
                        if "::" in line:
                            lst.append(line.split("::")[0])
                        else:
                            lst.append(line.split()[0])
                    elif end_netlist in line:
                        break
            finalnet_lst = []
            cnt=0
            for value in lst[1:]:
                finalnet_lst.append(re.sub('\s+','', value))
                cnt+=1
            if debug_mode:
                print("The finalnet_lst is:",finalnet_lst)
            with open('NetList.txt', 'w') as f:
                f.write('\n'.join(finalnet_lst))
            '''
            df = pd.DataFrame()
            df['Nets Available'] = finalnet_lst[0::]
            df.to_excel('NetList.xlsx', index=False)
            '''
            if debug_mode:
                print("The total cnt of net lists are:",cnt)
            return finalnet_lst
        else:
            print("Please provide valid spd file path")
            sys.exit()
    except Exception as err:
        print("Error Occurred.Please contact admin.")
        print("Error details: ")
        print(err)
        

        
#Save Command
def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd


#Tickle script write definition
def tcl_write2(finalnet_lst,psicmds_lst = []):
    req_nets = input("Enter the required net list: ")
    req_netlist = req_nets.split(",")
    #print("The req_net lists are:", req_netlist)
    psicmds_lst.append("sigrity::open document {" + spd_file_path + "} {!}\n")
    
    psicmds_lst.append("sigrity::update net selected 0 -all {!}\n")
    """

    #sigrity::update net selected 0 -all {!}
    #sigrity::move net {PowerNets} {VCCGT} {!}
    #sigrity::update net selected 1 {+V_12P0_BUS_FILT_GPU} {!}

    #for i in Net_lst:
    #    if i:
    #        psicmds_lst.append("sigrity::update net selected 0 {" + i + "} {!}" + "\n")
    
    """
    unmatched_nets=[]
    matched_nets=[]
    print("")
    print("Below are the selected nets: ")
    for i in req_netlist:
        if i in finalnet_lst:
            matched_nets.append(i)
            if i=='VSS':
                print(i)
                psicmds_lst.append("sigrity::update net selected 1 {" + i + "} {!}" + "\n")
                psicmds_lst.append("sigrity::move net {GroundNets} {" + i + "} {!}" + "\n")
            else:
                print(i)
                psicmds_lst.append("sigrity::update net selected 1 {" + i + "} {!}" + "\n")
                psicmds_lst.append("sigrity::move net {PowerNets} {" + i + "} {!}" + "\n")
        else:
            unmatched_nets.append(i)
    print("")
    if len(unmatched_nets):
        print("Below nets are not present in spd file: ")
        for i in unmatched_nets:
            print(i)
    value2=True
    while(value2):
        print("")
        value=input("Would you like to proceed with above selected nets(yes or no): ").lower()
        if value =="yes":
            print("")
            value2=False
        elif value == "no":
            print("")
            reentered_nets = input("Enter the required net list to be added: ")
            reentered_netlist = reentered_nets.split(",")
            for i in reentered_netlist:
                if i in finalnet_lst:
                    matched_nets.append(i)
                    if i=='VSS':
                        print(i)
                        psicmds_lst.append("sigrity::update net selected 1 {" + i + "} {!}" + "\n")
                        psicmds_lst.append("sigrity::move net {GroundNets} {" + i + "} {!}" + "\n")
                    else:
                        print(i)
                        psicmds_lst.append("sigrity::update net selected 1 {" + i + "} {!}" + "\n")
                        psicmds_lst.append("sigrity::move net {PowerNets} {" + i + "} {!}" + "\n")
                else:
                    unmatched_nets.append(i)
            print("")
            print("The selected nets are below:")
            for i in matched_nets:
                print(i)
            print("")
            print("Below nets not present in spd file:")
            for j in unmatched_nets:
                print(j)
            value2=True
        try:
            with open("selected_nets.txt", 'w') as fp:
                for value in matched_nets:
                    fp.write(value)
                    fp.write('\n')
        except Exception as error:
            print("Error while opening the selected nets.txt file", error)
    #save command
    psicmds_lst.append(cmd_save_file())
    return psicmds_lst
    
def execute_cmd2():
    #tcl_path=input("Enter the tcl file path: ")
    tcl_path=os.getcwd()
    if debug_mode:
        print("The tcl script file path is:",tcl_path)
    tclfile_path=tcl_path+"\\netselection.tcl"
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path
    print("Please wait!! Net Selection is in progress...")
    os.system(execute_cmd)
    print("Net Selection was completed successfully.")


def file_updation2(psicmds_lst):
    try:
        with open("netselection.tcl", 'w') as fp:
            fp.writelines(psicmds_lst)
        return True
    except Exception as error:
        print("Error while opening the net_select.tcl file",error)
        return False


#PHASE3 PORT CREATION AT COMPONENTS CODE
print("The current working directory is:", os.getcwd())

# Variables
start = "* Component description lines"
end = ".CompCollection"
line1 = ""
line2 = ""

def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-" * (width - 2))
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width - 4))
    print(g_line)


def selected_nets():
    my_text_frame("                                         PORT CREATION AT COMPONENTS".splitlines())
    global final_netlst
    final_netlst = []
    try:
        with open("selected_nets.txt", 'r') as fp:
            data = fp.read()
            final_netlst = data.split()
            #print("The netlist we read from selected_nets text file is: ", final_netlst)
    except Exception as error:
        print("Error while opening the selected_nets.txt file", error)
    data = True
    while (data):
        print("The selected net list from netselection is: ")
        for i in final_netlst:
            print(i)
        global ground_net
        print("")
        ground_net = input("Select the ground net name: ").upper()
        if ground_net in final_netlst:
            final_netlst.remove(ground_net)
            data = False
        elif ground_net:
            ground_net = input("Select the ground net name correctly from netlist: ").upper()
            if ground_net in final_netlst:
                final_netlst.remove(ground_net)
                data = False
        else:
            print("Empty Entered.Please check and select the ground net name from netlist: ")
    print("")
    if debug_mode:
        print("The final net list after removal of ground net is: ")
        for j in final_netlst:
                print(j)
        print("")


def get_components():
    try:
        data_lst = []
        components = []
        #global spd_file_path
        #spd_file_path = input(Fore.BLUE + Style.DIM + "Enter the path for spd file: " + Style.RESET_ALL)
        if (os.path.isfile(spd_file_path)):
            with open(spd_file_path, 'r') as fp:
                for line in fp:
                    # line.strip('\n')
                    if ".Connect" in line:
                        data_lst.append(re.sub(r'\n', '', line))
                        default_comp = ("BRDC", "PKGC")
                        for data in default_comp:
                            # if data in line:
                            if data in line.split()[1]:
                                value = True
                                while (value):
                                    line1 = next(fp)
                                    # line1.strip('\n')
                                    if ".EndC" not in line1:
                                        data_lst.append(re.sub(r'\n', '', line1))
                                    else:
                                        value = False
                                if debug_mode:
                                    print("The component data from .spd is: ", data_lst)
                                    print("The no.of lines along with .connect to .Endc line is: ", len(data_lst))
                                if len(data_lst) == 3:
                                    for net in final_netlst:
                                        if net == data_lst[1].split("::")[1] and ground_net in data_lst[2]:
                                            if debug_mode:
                                                print(
                                                    Fore.BLUE + Style.DIM + "THE COMPONENT AND MODELS FOR SELECTED NETS ARE:" + Style.RESET_ALL,
                                                    data_lst[0].split()[1], data_lst[0].split()[2])
                                            components.append(data_lst[0].split()[1])
                                        elif ground_net in data_lst[1] and net == data_lst[2].split("::")[1]:
                                            if debug_mode:
                                                print(
                                                    Fore.BLUE + Style.DIM + "THE COMPONENT AND MODELS FOR SELECTED NETS ARE:" + Style.RESET_ALL,
                                                    data_lst[0].split()[1],
                                                    data_lst[0].split()[2])
                                            components.append(data_lst[0].split()[1])

                        data_lst=[]
            # print("The final components are following: ",components)
            return components
        else:
            print("Please provide valid spd file path")
            sys.exit()
    except Exception as err:
        print("Error Occurred.Please contact admin.")
        print("Error details: ")
        print(err)


# Save Command
def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    if debug_mode:
        print("File is Saved Successfullly:")
    return cmd

# Tickle script write
def tcl_write3(final_components,psicmds_lst=[]):
    if debug_mode:
        print("Final Components Are Below: ",final_components)
    psicmds_lst.append("sigrity::open document {" + spd_file_path + "} {!}\n")
    psicmds_lst.append("sigrity::open window circuit {!}\n")
    l1="sigrity::select "
    l2="sigrity::update circuit -manual {disable} "
    l3="sigrity::add port -circuit "
    for compnent in final_components:
        l1=l1+"{"+compnent+"} "
        l2=l2+"{"+compnent+"} "
        l3 = l3 + "{" + compnent + "} "

    l1 = l1 + "{!}\n"
    psicmds_lst.append(l1)
    l2 = l2 + "{!}\n"
    psicmds_lst.append(l2)
    l3 = l3 + "{!}\n"
    psicmds_lst.append(l3)
    psicmds_lst.append("sigrity::close window port {!}\n")
    psicmds_lst.append(cmd_save_file())
    return psicmds_lst


# tcl file update
def file_updation3(cmds_lst):
    try:
        with open("porting.tcl", 'w') as fp:
            fp.writelines(cmds_lst)
        return True
    except Exception as error:
        print("Error while opening the net_select.tcl file", error)
        return False


# Execution of tcl file
def execute_cmd3():
    print("")
    # tcl_path = input(Fore.BLUE + Style.DIM +"Enter the tcl file path: "+ Style.RESET_ALL)
    tcl_path = os.getcwd()
    if debug_mode:
        print("The tcl file path is:", tcl_path)
    tclfile_path = tcl_path + "\\porting.tcl"
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path
    print("Please wait!! Porting is in progress...")
    # print("This command is executing: ",execute_cmd)
    os.system(execute_cmd)
    print("Ports are created successfully.")



##PHASE4 CAP MODEL ASSIGNATION AT COMPONENTS CODE

psicmds_lst = []

# Variables
start = "* Component description lines"
end = ".CompCollection"
line1 = ""
line2 = ""
global final_netlst
global ground_net

#Heading display
def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-" * (width - 2))
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width - 4))
    print(g_line)


#Selection of Nets From Phase2 Net selection
def selected_nets4():
    my_text_frame("                                         CAP MODEL ASSIGNATION".splitlines())
    global final_netlst
    final_netlst = []
    try:
        with open("selected_nets.txt", 'r') as fp:
            data = fp.read()
            final_netlst = data.split()
            #print("The netlist we read from selected_nets text file is: ", final_netlst)
    except Exception as error:
        print("Error while opening the selected_nets.txt file", error)
    data = True
    while (data):
        print("The selected net list from netselection is: ")
        for i in final_netlst:
            print(i)
        global ground_net
        print("")
        ground_net = input("Select the ground net name: ").upper()
        if ground_net in final_netlst:
            final_netlst.remove(ground_net)
            data = False
        elif ground_net:
            ground_net = input("Select the ground net name correctly from netlist: ").upper()
            if ground_net in final_netlst:
                final_netlst.remove(ground_net)
                data = False
        else:
            print("Empty Entered.Please check and select the ground net name from netlist: ")
    print("")
    if debug_mode:
        print("The final net list after removal of ground net is: ")
        for j in final_netlst:
                print(j)
        print("")


#Get Model Names From .SPD file
def get_models4():
    try:
        data_lst=[]
        model_names=[]
        if (os.path.isfile(spd_file_path) and os.stat(spd_file_path).st_size != 0):
            with open(spd_file_path,'r') as fp:
                for line in fp:
                    #line.strip('\n')
                    if ".Connect" in line:
                        data_lst.append(re.sub(r'\n', '', line))
                        default_comp=("BRDC","PKGC")
                        for data in default_comp:
                            #if data in line:
                            if data in line.split()[1]:
                                value=True
                                while(value):
                                    line1 = next(fp)
                                    #line1.strip('\n')
                                    if ".EndC" not in line1:
                                        data_lst.append(re.sub(r'\n', '', line1))
                                    else:
                                        value=False
                                if len(data_lst) == 3:
                                    for net in final_netlst:
                                        if net in data_lst[1] and ground_net in data_lst[2]:
                                            if debug_mode:
                                                print("THE COMPONENT AND MODELS FOR SELECTED NETS ARE:",data_lst[0].split()[1],data_lst[0].split()[2])
                                            value1=data_lst[0].split()[2]
                                            if value1 not in model_names:
                                                model_names.append(value1)
                                        elif ground_net in data_lst[1] and net in data_lst[2]:
                                            if debug_mode:
                                                print("THE COMPONENT AND MODELS FOR SELECTED NETS ARE:", data_lst[0].split()[1],data_lst[0].split()[2])
                                            value2=data_lst[0].split()[2]
                                            if value2 not in model_names:
                                                model_names.append(value2)
                                data_lst=[]
            if debug_mode:
                print("The final model_names are following: ",model_names)
            return model_names
        else:
            print("Please provide valid spd file path or may be the file is empty")
            sys.exit()
    except Exception as err:
        print("Error Occurred.Please contact admin.")
        print("Error details: ")
        print(err)

def assign_models():
    wb = openpyxl.load_workbook(filename="sample_book.xlsx")
    ws = wb.active
    assignedLst = []
    for val in ws['B']:
        if val != ws['B1']:
            if val.value != None:
                assignedLst.append(val.value)
            else:
                print("Please enter the Assigned values Column to the excel file - sample_book.xlsx to proceed further")
                sys.exit()
    wb.save(filename="sample_book.xlsx")
    return assignedLst

#Get Assigned Model Names from Xcel File
def model_names_read(final_models4):
    assign_mdllst=[]
    global original_comp
    original_comp=[]
    original_comp=final_models4
    if os.path.exists('sample_book.xlsx'):
        if debug_mode:
            print("Venkat boy already the file is present")
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "Model Names"
        ws.cell(1, 1, "Model Values")
        ws.cell(1, 2, "Assigned Values")
        row = 2
        col = 1
        for i in final_models4:
            ws.cell(row=row, column=col, value=i)
            row += 1
        wb.save(filename='sample_book.xlsx')
    print(Fore.YELLOW +"PLEASE ENTER THE CORRESPONDING ASSIGNED MODEL NAMES IN Sample_book.xlsx"+ Style.RESET_ALL)
    excel_filepath=os.getcwd()+"Sample_book.xlsx"
    print("The path of the excel file is: ",excel_filepath)
    time.sleep(15)
    valueloop=True
    
    while(valueloop):
        #value = input("Assiged model names required to match with .sp file? (yes or no) : ").lower()
        value = input("Would you like to read assign model names from .sp file? (yes or no) : ").lower()
        if value == "yes":
            assign_mdllst=assign_models()
            valueloop=False
        elif value == "no":
            print("Please re-check the Assigned Values Column in Sample_book.xlsx")
            print("Please enter the Assigned values Column to the excel file - sample_book.xlsx to proceed further")
            #valueloop=False
        else:
            print("Please check and enter the input in (yes or no) format")
    return assign_mdllst


#Reading .SP file and comparing model names with respect to Assigned Model Names list
def new_mdldata(mlst):
    un_matchedlst=[]
    with open("cap_model_file.sp","r") as fm:
        for line in fm:
            if line.startswith("*Capacitor partnumber"):
                linex = re.sub(r'\n', '', line)
                model_name = linex.split(" ")[-1]
                if debug_mode:
                    print("The model name from model.txt before matching is: ", model_name)
                if model_name in mlst:
                    global index_value
                    index_value=mlst.index(model_name)
                    if debug_mode:
                        print("The model name from model.txt after matching is: ", model_name)
                        print("VENKATESH CHECK-1")
                    value = True
                    try:
                        while (value):
                            global mdl_data_lst
                            mdl_data_lst = []
                            line1 = next(fm)
                            if ".SUBCKT" in line1:
                                if debug_mode:
                                    print("VENKATESH CHECK-3")
                                    print("Hello inside the requirement point")
                                mdl_data_lst.append(re.sub(r'\n', '', line1))
                                lineparam=next(fm)
                                mdl_data_lst.append(re.sub(r'\n', '', lineparam))
                                mdl_data_lst.append("+ NCAPS = 1")
                                value2 = True
                                while (value2):
                                    line2 = next(fm)
                                    if ".ENDS" not in line2:
                                        mdl_data_lst.append(re.sub(r'\n', '', line2))
                                    else:
                                        value2 = False
                                mdl_data_lst.append(re.sub(r'\n', '', line2))
                                newtcl_write(mdl_data_lst,index_value)
                                value=False
                            elif ".ENDS" in line1:
                                value = False
                                # value = False
                    except StopIteration:
                        print("successfully done")
                else:
                    un_matchedlst.append(model_name)
    #if un_matchedlst != None:
    if len(un_matchedlst):
        print("This model names are not matched with Assigned list Column: ", un_matchedlst)
    #print("The modelnames from .sp doesnt match with assigned values list.")
                    

#capassignation.tcl File write 
def newtcl_write(mdldata_lst,index_value):
    closecmds_lst=[]
    line10 = "sigrity::open document {" + spd_file_path + "} {!}\n"
    if line10 not in psicmds_lst:
        psicmds_lst.append(line10)
    line11 = "sigrity::open window circuit {!}\n"
    if line11 not in psicmds_lst:
        psicmds_lst.append(line11)
    if debug_mode:
        print("The original components are following:",original_comp)
    model_naam=original_comp[index_value]
    line12 = "sigrity::update cktdef {" + model_naam + "} -Definition {"
    for i in mdldata_lst:
        line12 = line12 + i
        line12 = line12 + "\n"
    line12 = line12 + "} -check {!}\n"
    if debug_mode:
        print("The line 12 data is: ", line12)
    psicmds_lst.append(line12)
    if debug_mode:
        print("The psicmds list data is: ", psicmds_lst)
    line13="sigrity::close window port {!}\n"
    closecmds_lst.append(line13)
    line14="sigrity::save {!}"
    closecmds_lst.append(line14)
    try:
        with open("capassignation.tcl", 'w') as fp:
            fp.writelines(psicmds_lst)
            fp.writelines(closecmds_lst)
        return True
    except Exception as error:
        print("Error while opening the porting.tcl file", error)
        return False

# Execution of tcl file
def execute_cmd4():
    print("")
    # tcl_path = input(Fore.BLUE + Style.DIM +"Enter the tcl file path: "+ Style.RESET_ALL)
    tcl_path = os.getcwd()
    if debug_mode:
        print("The tcl file path is:", tcl_path)
    tclfile_path = tcl_path + "\\capassignation.tcl"
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path
    print("Please wait!! cap model assignation is in progress...")
    # print("This command is executing: ",execute_cmd)
    os.system(execute_cmd)
    print("Cap Model Assignation is completed successfully.")

    

#EXECUTING PROCESS

def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width-4))
    print(g_line)

def brd_pkg():
    file_updation1(get_input_from_user(cmd_list=[]))
    tcl_execution()

def net_select():
    file_updation2(tcl_write2(spd_read(lst=[]),psicmds_lst = []))
    execute_cmd2()

def porting_comp():
    selected_nets()
    final_components = get_components()
    #print(Fore.BLUE + Style.DIM +"The final components are following: "+Style.RESET_ALL, final_components)
    cmds_lst=tcl_write3(final_components,psicmds_lst=[])

    file_updation3(cmds_lst)
    execute_cmd3()

def cap_assignation():
    selected_nets4()
    final_models4 = get_models4()
    assign_mdllst = model_names_read(final_models4)
    new_mdldata(assign_mdllst)
    execute_cmd4()
    

def inside_loop():
    print("")
    value1 = input("Net selection required? (yes or no) : ").lower()
    if value1 == "yes":
        net_select()
        print("")
        while(1):
            print("Select anyone of the below mentioned options: ")
            print("1 - Port Creation \n2 - Cap Model Assignation ")
            print("")
            value3=input("Enter 1 for portcreation or 2 for capassignation: ").lower()
            if value3 == "1":
                porting_loop()
                print("Thank You!!")
                time.sleep(20)
                sys.exit()
            elif value3 == "2":
                cap_model()
                print("Thanks You!!")
                sys.exit()
            else:
                print("Please check and enter the input in (portcreation or capassignation) format")
    elif value1 == "no":
        print("Thank you!!")
        time.sleep(10)
        sys.exit()
    else:
        print("Please check and enter the input in (yes or no) format")

def cap_model():
    value2=input("cap model assignation required? (yes or no): ").lower()
    if value2=="yes":
        cap_assignation()
        print("")
        print("Thank you!!")
        time.sleep(20)
        sys.exit()
    elif value2=="no":
        print("Thank you!!")
        time.sleep(10)
        sys.exit()
    else:
        print("Please check and enter the input in (yes or no) format")

def porting_loop():
    value2=input("Port Creation at Components required? (yes or no): ").lower()
    if value2=="yes":
        porting_comp()
        print("")
        print("Thank you!!")
        time.sleep(20)
        sys.exit()
    elif value2=="no":
        print("Thank you!!")
        time.sleep(10)
        sys.exit()
    else:
        print("Please check and enter the input in (yes or no) format")
    
def pi_process_automation():
    my_text_frame("                                         Welcome To PI Process Automation".splitlines())
    while(1):
        print("")
        value = input("Board and Package file merge required ? (yes or no) : ").lower()
        if value == "yes":
            brd_pkg()
            print("")
            while(1):
                inside_loop()
        elif value == "no":
            while(1):
               inside_loop()
        else:
            print("Please check and enter the input in (yes or no) format")



if __name__ == "__main__":
    pi_process_automation()
    print("")
    print("Thank You!!")
    




