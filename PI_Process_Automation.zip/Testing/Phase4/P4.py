import os,re,sys
from colorama import Fore, Back, Style

#colorama.init(autorest=True)

print(os.getcwd())
psicmds_lst = []

# debug_mode mode for developer
debug_mode = True

#Variables
#VCCGT,VSS
start="* Component description lines"
end=".CompCollection"
line1=""
line2=""

# PowerSI installed path on the local machine
powersi_path = "C:\\Cadence\\Sigrity2021.1\\tools\\bin\\PowerSI.exe"

def selected_nets():
    #final_netlst=['VCCGT','VSS','VRRMT']
    #my_text_frame("                                         PORT CREATION AT COMPONENTS".splitlines())
    global final_netlst
    final_netlst = []
    try:
        with open("selected_nets.txt", 'r') as fp:
            data = fp.read()
            final_netlst = data.split()
            print("The netlist we read from selected_nets text file is: ", final_netlst)
    except Exception as error:
        print("Error while opening the selected_nets.txt file", error)
    data = True
    while (data):
        print(Fore.BLUE + Style.DIM + "The selected net list from phase2 netselection is: " + Style.RESET_ALL,
              final_netlst)
        global ground_net
        ground_net = input(Fore.BLUE + Style.DIM + "Enter the ground net name: " + Style.RESET_ALL).upper()
        if ground_net in final_netlst:
            final_netlst.remove(ground_net)
            data = False
        elif ground_net:
            ground_net = input(
                Fore.BLUE + Style.DIM + "Select the ground net name correctly from netlist: " + Style.RESET_ALL).upper()
            if ground_net in final_netlst:
                final_netlst.remove(ground_net)
                data = False
        else:
            print("Empty Entered.Please check and select the ground net name from netlist: ")

    print(Fore.BLUE + Style.DIM + "The final net list after removal of ground net is: " + Style.RESET_ALL, final_netlst)

def get_components():
    try:
        data_lst=[]
        components=[]
        global spd_file_path
        spd_file_path = input("Enter the path for spd file: ")
        #if (os.path.isfile(spd_file_path) and os.stat(spd_file_path).st_size == 0):
        if (os.path.isfile(spd_file_path) and os.stat(spd_file_path).st_size != 0):
            with open(spd_file_path,'r') as fp:
                for line in fp:
                    #line.strip('\n')
                    if ".Connect" in line:
                        data_lst.append(re.sub(r'\n', '', line))
                        default_comp=("BRDC","PKGC")
                        for data in default_comp:
                            #if data in line:
                            if data in line.split()[1]:
                                value=True
                                while(value):
                                    line1 = next(fp)
                                    #line1.strip('\n')
                                    if ".EndC" not in line1:
                                        data_lst.append(re.sub(r'\n', '', line1))
                                    else:
                                        value=False
                                #print("The component data from .spd is: ",data_lst)
                                #print("The no.of nodes along with component is: ",len(data_lst))
                                if len(data_lst) == 3:
                                    for net in final_netlst:
                                        if net in data_lst[1] and ground_net in data_lst[2]:
                                            if debug_mode:
                                                print("THE COMPONENT AND MODELS FOR SELECTED NETS ARE:",data_lst[0].split()[1],data_lst[0].split()[2])
                                            #components.append((data_lst[0].split()[1],data_lst[0].split()[2]))
                                            #components.append(data_lst[0].split()[2])
                                            value1=data_lst[0].split()[2]
                                            if value1 not in components:
                                                components.append(value1)

                                        elif ground_net in data_lst[1] and net in data_lst[2]:
                                            if debug_mode:
                                                print("THE COMPONENT AND MODELS FOR SELECTED NETS ARE:", data_lst[0].split()[1],data_lst[0].split()[2])
                                            #components.append((data_lst[0].split()[1], data_lst[0].split()[2]))
                                            #components.append(data_lst[0].split()[2])
                                            value2=data_lst[0].split()[2]
                                            if value2 not in components:
                                                components.append(value2)
                                data_lst=[]
                            #elif ".CompCollection" in line:
                            #    print("The Components part in the spd are done")
            if debug_mode:
                print("The final components are following: ",components)
            return components
        else:
            print("Please provide valid spd file path or may be the file is empty")
            sys.exit()
    except Exception as err:
        print("Error Occurred.Please contact admin.")
        print("Error details: ")
        print(err)

# Save Command
def cmd_save_file():
    cmd = "sigrity::save {!} \n"
    return cmd

def model_names(final_components):
    global final_mdllst,original_brdlst
    original_brdlst=[]
    final_mdllst=[]
    for i in final_components:
        if i.startswith("BRD"):
            original_brdlst.append(i)
            if debug_mode:
                print("The models starting with BRD is: ",i)
            mdl = ""
            for j in i:
                if not j.isalpha():
                    mdl = mdl + j
            final_mdllst.append(mdl)
    if debug_mode:
        print("The model list is following: ",final_mdllst)
    return final_mdllst

def new_mdldata(mlst):
    #mdldata_lst = []
    abcd=[]
    with open("model.txt","r") as fm:
        for line in fm:
            if line.startswith("*Capacitor partnumber"):
                linex = re.sub(r'\n', '', line)
                model_name = linex.split(" ")[-1]
                #print("The model name from model.txt is: ", model_name)
                if model_name in mlst:
                    global index_value
                    index_value=mlst.index(model_name)
                    print("The model name from model.txt is: ", model_name)
                    #print("VENKATESH CHECK-1")
                    value = True
                    try:
                        while (value):
                            mdldata_lst = []
                            line1 = next(fm)
                            if ".SUBCKT" in line1:
                                #print("VENKATESH CHECK-3")
                                print("Hello inside the requirement point")
                                mdldata_lst.append(re.sub(r'\n', '', line1))
                                value2 = True
                                while (value2):
                                    #print("VENKATESH CHECK-4")
                                    line2 = next(fm)
                                    if ".ENDS" not in line2:
                                        mdldata_lst.append(re.sub(r'\n', '', line2))
                                    else:
                                        value2 = False
                                mdldata_lst.append(re.sub(r'\n', '', line2))
                                #print("The mdldata_lst for every loop is: ", mdldata_lst)
                                newtcl_write(mdldata_lst,index_value)
                                value=False
                            elif ".ENDS" in line1:
                                value = False
                                # value = False
                    except StopIteration:
                        print("successfully done")
        #print("The model definition data from model.txt is: ",mdldata_lst)
    return mdldata_lst

def newtcl_write(mdldata_lst,index_value):
    line10="sigrity::open document {" + spd_file_path + "} {!}\n"
    if line10 not in psicmds_lst:
        psicmds_lst.append(line10)
    line11="sigrity::open window circuit {!}\n"
    if line11 not in psicmds_lst:
        psicmds_lst.append(line11)
    model_naam=original_brdlst[index_value]
    line12 = "sigrity::update cktdef {" + model_naam + "} -Definition {"
    for i in mdldata_lst:
        line12 = line12 + i
        line12 = line12 + "\n"
    line12 = line12 + "} -check {!}\n"
    if debug_mode:
        print("The line 12 data is: ", line12)
    psicmds_lst.append(line12)
    if debug_mode:
        print("The psicmds list data is: ", psicmds_lst)
    try:
        psicmds_lst.append(cmd_save_file())
        with open("capmodel.tcl", 'w') as fp:
            fp.writelines(psicmds_lst)
        return True
    except Exception as error:
        print("Error while opening the porting.tcl file", error)
        return False

#Execution of tcl file
def execute_cmd():
    print("")
    tcl_path = input("Enter the tcl file path: ")
    tclfile_path = tcl_path + "\\porting.tcl"
    execute_cmd = powersi_path + " -PSPowerSI -b -tcl " + tclfile_path
    print("Please wait!! Porting is in progress...")
    os.system(execute_cmd)
    print("Ports are created successfully.")

if __name__=="__main__":
    selected_nets()
    final_components = get_components()

    print("The final components are following: ", final_components)
    mlst = model_names(final_components)
    print("The model list is following: ", mlst)
    mdl_lst=new_mdldata(mlst)

    #newtcl_write(mdl_lst)


    #cmds_lst=tcl_write(final_components,psicmds_lst=[])

    #file_updation(cmds_lst)

    #execute_cmd()







