#import brd_pkg_merge as brdpkg
#import net_select as netsel
#import portingcomponents as portcomp
import main as pi
import sys,time

def my_text_frame(string_lst, width=115):
    g_line = "+{0}+".format("-"*(width-2))
    print(g_line)
    for line in string_lst:
        print("| {0:<{1}} |".format(line, width-4))
    print(g_line)

def brd_pkg():
    pi.file_updation1(pi.get_input_from_user(cmd_list=[]))
    pi.tcl_execution()

def net_select():
    pi.file_updation2(pi.tcl_write2(pi.spd_read(lst=[]),psicmds_lst = []))
    pi.execute_cmd2()

def porting_comp():
    pi.selected_nets()
    final_components = pi.get_components()
    #print(Fore.BLUE + Style.DIM +"The final components are following: "+Style.RESET_ALL, final_components)
    cmds_lst=pi.tcl_write3(final_components,psicmds_lst=[])

    pi.file_updation3(cmds_lst)

    pi.execute_cmd3()

    

def inside_loop():
    print("")
    value1 = input("Net selection required? (yes or no) : ").lower()
    if value1 == "yes":
        net_select()
        print("")
        while(1):
            porting_loop()
        print("Thank You!!")
        time.sleep(20)
        sys.exit()
    elif value1 == "no":
        print("Thank you!!")
        time.sleep(10)
        sys.exit()
    else:
        print("Please check and enter the input in (yes or no) format")

def porting_loop():
    value2=input("Port Creation at Components required? (yes or no): ").lower()
    if value2=="yes":
        porting_comp()
        print("")
        print("Thank you!!")
        time.sleep(20)
        sys.exit()
    elif value2=="no":
        print("Thank you!!")
        time.sleep(10)
        sys.exit()
    else:
        print("Please check and enter the input in (yes or no) format")
        
def pi_process_automation():
    my_text_frame("                                         Welcome To PI Process Automation".splitlines())
    while(1):
        print("")
        value = input("Board and Package file merge required ? (yes or no) : ").lower()
        if value == "yes":
            brd_pkg()
            print("")
            while(1):
                inside_loop()
        elif value == "no":
            while(1):
               inside_loop()
        else:
            print("Please check and enter the input in (yes or no) format")
                
        

if __name__=="__main__": 
    pi_process_automation()
    print("")
    print("Thank You!!")
